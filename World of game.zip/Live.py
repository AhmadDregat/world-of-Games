import CurrencyRouletteGame
import GuessGame
import MemoryGame


def welcome():
    name = input('Welcome, please enter your name.\n')
    return "\nHello " + name.capitalize() + " and welcome to the World of Games (WoG).\nHere you can find many cool games to play.\n\n"

###get_difficulty is a function that checks the input

def get_difficulty():
  try:
    number = int(input("Please choose game difficulty from 1 to 5:\n"))
    if 0 < number < 6:
        if number == 1:
            print ("Easy")
        elif number == 2:
            print ("Medium")
        elif number == 3:
               print ("Hard")
        elif number == 4:
               print ("Insane")
        else:
               print ("Insane")
    else:
         print('Please choose a valid option\n')
         get_difficulty()
  except ValueError:
      print("The provided value is not an integer")
      get_difficulty()
  return number

##load_game is a function that loads the game
def load_game():

    print("Please choose a game to play:")
    print("1. Memory Game - a sequence of numbers will appear for 1 second and you have to guess it back")
    print("2. Guess Game - guess a number and see if you chose like the computer")
    print("3. Currency Roulette - try and guess the value of a random amount of USD in ILS")
    try:
        game_number = int(input())
        if 0 < game_number < 4:

            if game_number == 1:
                MemoryGame.play(get_difficulty())
            elif game_number == 2:
                GuessGame.play(get_difficulty())
            elif game_number == 3:
                CurrencyRouletteGame.play(get_difficulty())
        else:
            print("please enter a number and try again")
            load_game()
    except ValueError:
        print("The provided value is not an integer")
        load_game()
