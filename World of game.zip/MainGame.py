from Live import load_game, welcome
print(welcome())
load_game()